import 'package:flutter/cupertino.dart';

class ViewReportFragment extends StatelessWidget
{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Center(
      child: new Text("View Report Fragment"),
    );
  }



}