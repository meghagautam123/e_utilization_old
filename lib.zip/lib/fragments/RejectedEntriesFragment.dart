
import 'package:flutter/material.dart';

class RejectedEntriesFragment extends StatelessWidget
{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Center(
      child: new Text("Rejected Entries Fragment"),
    );
  }
  
  
  
  
  
}