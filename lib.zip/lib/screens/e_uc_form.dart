//import 'package:e_utilization/screens/e_uc_form_camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'e_uc_form_camera.dart';

class EForm extends StatefulWidget {
  @override
  State<EForm> createState() => _EFormState();

}

class _EFormState extends State<EForm> {
  TextEditingController _textEditingController = TextEditingController();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

   // _textEditingController.text = "jkhkjhkj";
  }


  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
    appBar:AppBar(title: Center(child: Text("E-UC Form",style: TextStyle(fontSize: 20,color: Colors.black,fontFamily: 'RobotoBold',
        fontWeight: FontWeight.bold),)),backgroundColor: Colors.red.withOpacity(0.8)),


      body: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
         /* Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
            child: Text(
              "E UC Form ",
              style: TextStyle(
                  color: Colors.brown, fontFamily: 'RobotoBold', fontSize: 20),
            ),
          ),*/
          SizedBox(
            height: 20,
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0,0.0,0.0,10.0),
            child: Text("Allocating Ministry",style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),



          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: TextField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0,10.0,0.0,0.0),
            child: Text("Scheme Name",style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),

            child: TextField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(10.0,10.0,0.0,0.0),
            child: Text("FY",style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),

            child: TextField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),



          Padding(
            padding: const EdgeInsets.fromLTRB(10.0,10.0,0.0,0.0),
            child: Text("Unspent Balance",style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),

            child: TextField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),


          /*Visibility(visible: isVisible, child: Text("date new")),*/

          //Button
          /* Container(
            height: 50.0,
            child:*/

          SizedBox(height: 40,),
          Padding(
            padding: const EdgeInsets.fromLTRB(
                0.0, 0.0, 0.0, 30.0),
            child: Center(
              child: SizedBox(
                width: 180,
                height: 40,
                child: ElevatedButton(

                  style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(

                          borderRadius:
                          BorderRadius.circular(10.0)),

                      backgroundColor: Colors.red.withOpacity(0.8),

                   /*   padding: EdgeInsets.symmetric(
                          horizontal:
                          MediaQuery
                              .of(context)
                              .size
                              .width /
                              3.3,
                          vertical: 20)*/

                    // padding: EdgeInsets.only(
                    //     left: 120, right: 120, top: 20, bottom: 20),
                  ),

                  onPressed: ()
                  {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => EFormCamera()));


                    /*    if (_formKey.currentState!.validate()) {
    ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
    backgroundColor: Colors.white,
    content: Text(
    'Validation Successful',
    style: TextStyle(
    color: Colors.black,
    ),
    ),
    ),
    );
*/
                    //}

                  },
                  child: const Text(
                    'Submit E-UC',
                    style: TextStyle(
                        fontSize: 17, color: Colors.white),
                  ),
                ),
              ),
            ),
          ),


        ]),
      ),
    );
  }

}
