
import 'dart:io';

import 'package:e_utilization/database/DbManager.dart';
import 'package:e_utilization/model/EUCFormCameraModel.dart';
import "package:geocoding/geocoding.dart";
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../navigationDrawer/navigationDrawer.dart';




class EFormCamera extends StatefulWidget {
  @override
  State<EFormCamera> createState() => _EFormCameraState();

}


class _EFormCameraState extends State<EFormCamera> {

  File? imageFile;
  List<File> _imageList = [];
  bool _visible = false;
   String latitude="";
   String longitude="";
  TextEditingController schemeController = TextEditingController();
  TextEditingController fyController = TextEditingController();
  TextEditingController expenditureController = TextEditingController();
  TextEditingController latitudeController = TextEditingController();
  TextEditingController longitudeController = TextEditingController();
  TextEditingController remarkController = TextEditingController();
  DbManager dbHandler = DbManager();
  var image;
  List imageArray = [];

  final ImagePicker picker = ImagePicker();
  String location ='Null, Press Button';
  String Address = 'search';


  bool visible = false ;

  loadProgress() {
   /* if (visible == true) {
      setState(() {
        visible = false;
      });
    }*/

      setState(() {
        visible = true;
      });
  //  }
  }
    /*

  Future<List<Address>> getAddress(double lat, double lang) async {
    final coordinates = new Coordinates(latitude, longitude);
    List<Address> address =
    await Geocoder.local.findAddressesFromCoordinates(coordinates);
    return address;
  }
*/


  _openCamera() async {
    XFile? image = await picker.pickImage(source: ImageSource.camera);
    imageArray.add(image);
    setState(() {
      imageArray;
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
      appBar: AppBar(title: Center(child: Text("E-UC Form", style: TextStyle(
          fontSize: 20,
          color: Colors.black,
          fontFamily: 'RobotoBold',
          fontWeight: FontWeight.bold),)),
          backgroundColor: Colors.red.withOpacity(0.8)),
      body: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          /*  Padding(
        padding: const EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
        child: Text(
          "E UC Form ",
          style: TextStyle(
              color: Colors.brown, fontFamily: 'RobotoBold', fontSize: 20),
        ),
    ),*/
          SizedBox(
            height: 20,
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 10.0),
            child: Text("Scheme Name",
              style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: TextField(

              controller: schemeController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
            child: Text(
              "FY", style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),

            child: TextField(
              controller: fyController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
            child: Text("Expenditure",
              style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),

            child: TextField(
              controller: expenditureController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),

          SizedBox(height: 20,),


          //Capture Photos Button
          Padding(
            padding: const EdgeInsets.fromLTRB(
                10.0, 0.0, 0.0, 15.0),
            child: SizedBox(
              width: 170,
              height: 45,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(8.0)),
                  backgroundColor:
                  Colors.red.withOpacity(0.8),

                ),
                onPressed: () {
//selectImages();

                  if(_imageList.length<2) {

                    _getFromCamera();

                  }
                  else
                  {
                    showToast();
                  }


                },
                child: const Text(
                  'Capture Photos',
                  style: TextStyle(
                      fontSize: 17, color: Colors.white),
                ),
              ),
            ),
          ),

          if(_imageList.isNotEmpty)
//if(_imageList.length)
      /*Container( child: Image.file(
                  imageFile!!, width: 200,
                   height: 200))*/



      /*    Expanded(
                    child:*/
      Container(width:400,height:150,child:
    ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _imageList.length,
        itemBuilder: (context, index) {

          return InkWell(
              onTap: () {
                return null;
              },
              child: Card(
                child: Container(
                  child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: /*Text(_imageList[index].path),*/
                      Image.file(_imageList[index] )

                  ),

                ),
              ));
        }),
    ),




          /* Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: GridView.builder(
                  itemCount: imageFileList!.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3),
                  itemBuilder: (BuildContext context, int index) {
                    return Image.file(File(imageFileList![index].path) as File, fit: BoxFit.cover,);
                  }),
            ),
        ),*/
          //Capture Location Button



          Padding(
            padding: const EdgeInsets.fromLTRB(
                10.0, 20.0, 0.0, 20.0),
            child: SizedBox(
              width: 190,
              height: 45,
              child: ElevatedButton(

                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(8.0)),
                  backgroundColor:
                  Colors.red.withOpacity(0.8),

                  /*  padding: EdgeInsets.only(
                      left: 0, right: 0, top: 20, bottom: 15),*/
                ),
                onPressed: ()
                  //}

                {
loadProgress();
             getCurrentPosition();
          //   _showLatLongText();



                },

                child: const Text(
                  'Capture Location',
                  style: TextStyle(
                      fontSize: 17, color: Colors.white),
                ),
              ),
            ),
          ),

          Visibility(
            /*  maintainSize: true,
              maintainAnimation: true,
              maintainState: true,*/
              visible: visible,
              child: Center(
                child: Container(
                  // margin: EdgeInsets.only(top: 50, bottom: 30),
                    child: CircularProgressIndicator()
                ),
              )
          ),

          Visibility(child: Padding(
            padding: const EdgeInsets.fromLTRB(10.0,20.0,0.0,0.0),
            child: Text(style: TextStyle(fontSize: 17,color: Colors.red.withOpacity(0.8),fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),"Latitude: "+latitude + ","+ " Longitude: "+longitude),
          ), visible: _visible,),



          //Add Remarks Text
          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 15.0, 0.0, 0.0),
            child: Text("Add Remarks",
              style: TextStyle(fontSize: 18, color: Colors.black,fontFamily: 'RobotoBold',fontWeight: FontWeight.bold),),
          ),

          SizedBox(height: 20,),

          Padding(
            padding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),

            child: TextField(
              controller: remarkController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: Colors.black), //<-- SEE HERE
                ),
              ),
            ),
          ),




          SizedBox(height: 20,),
          //Save,Submit Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [ ElevatedButton(
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius:
                    BorderRadius.circular(8.0)),
                backgroundColor:
                Colors.red.withOpacity(0.8),

              ), onPressed: () async {
    EUCForm user =EUCForm.empty();
    user.scheme = schemeController.text.toString();
    user.fy =fyController .text.toString();
    user.expenditure =expenditureController .text.toString();
    user.latitude="jgh";
    user.longitude="jgjgj";
    user.remark =remarkController .text.toString();




var result= await dbHandler.insertUser(user);
  /*  initState();
    setState(() {





    });*/
print(result);
if(result>=1)
  {
    Fluttertoast.showToast(
        msg: "Data Saved Success",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.yellow
    );
  }
else
  {
    Fluttertoast.showToast(
        msg: "Data Not Inserted",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.yellow
    );

  }

    }, child: const Text(
              'Save',
              style: TextStyle(
                  fontSize: 17, color: Colors.white),
            ),),

              SizedBox(width: 30,),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(8.0)),
                  backgroundColor:
                  Colors.red.withOpacity(0.8),

                ), onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => navigationDrawer()));
              },
                child: const Text(
                  'Submit',
                  style: TextStyle(
                      fontSize: 17, color: Colors.white),
                ),)
            ],


          ),


        ]),
      ),
    );
  }
  void showToast() {
    Fluttertoast.showToast(
        msg: 'You cannot add more than 2 images',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.yellow
    );
  }
void getCurrentPosition() async
  {
LocationPermission locationPermission=await Geolocator.checkPermission();
if(locationPermission==LocationPermission.denied||locationPermission==LocationPermission.deniedForever)
  {
  LocationPermission asked=await  Geolocator.requestPermission();
  }
else
  {
  Position currentPosition=await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);

 setState(() {
   visible=false;
  _visible = !_visible;
   latitude= currentPosition.latitude.toString();
   longitude= currentPosition.longitude.toString();


 });
  print("Latitude"+ currentPosition.latitude.toString());
  print("Longitude"+ currentPosition.longitude.toString());
 // showToast();

  Fluttertoast.showToast(
      msg: ''+currentPosition.longitude.toString(),
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.yellow
  );
  }
  }

/*void _showLatLongText()
{
  setState(() {
    _visible = !_visible;


  });

}*/

  Future<Position> _getGeoLocationPosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {

        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }
  Future<void> GetAddressFromLatLong(Position position)async {
    List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
    print(placemarks);
    Placemark place = placemarks[0];
    Address = '${place.street}, ${place.subLocality}, ${place.locality}, ${place.postalCode}, ${place.country}';
    setState(()  {
    });
  }

  /// Get from Camera
  _getFromCamera() async {
    final image = await ImagePicker().pickImage(
        source: ImageSource.camera);

    imageFile=File(image!.path);
    _addImage(imageFile!!);

  }
  void _addImage(File _image) {
    setState(() {
      _imageList.add(_image);
    });
  }





}